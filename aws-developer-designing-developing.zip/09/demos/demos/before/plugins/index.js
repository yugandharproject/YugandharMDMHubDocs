module.exports = [
  require('@hapi/inert'),
  require('@hapi/cookie')
]
